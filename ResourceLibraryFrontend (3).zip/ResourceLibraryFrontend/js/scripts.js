const resources = [
    {
        title: "Introduction to Algebra",
        description: "A comprehensive guide to the basics of algebra.",
        link: "#"
    },
    {
        title: "World History: Ancient Civilizations",
        description: "Learn about ancient civilizations around the globe.",
        link: "#"
    },
    {
        title: "Introduction to Java Programming",
        description: "Learn Java programming with easy-to-understand examples.",
        link: "#"
    }
];

function loadResources() {
    const resourceList = document.getElementById('resourceList');
    resourceList.innerHTML = '';

    resources.forEach(resource => {
        const card = document.createElement('div');
        card.classList.add('resource-card');
        card.innerHTML = `
            <h3>${resource.title}</h3>
            <p>${resource.description}</p>
            <a href="${resource.link}">Access Resource</a>
        `;
        resourceList.appendChild(card);
    });
}

function searchResources() {
    const query = document.getElementById('searchBar').value.toLowerCase();
    const filteredResources = resources.filter(resource => resource.title.toLowerCase().includes(query));

    const resourceList = document.getElementById('resourceList');
    resourceList.innerHTML = '';

    filteredResources.forEach(resource => {
        const card = document.createElement('div');
        card.classList.add('resource-card');
        card.innerHTML = `
            <h3>${resource.title}</h3>
            <p>${resource.description}</p>
            <a href="${resource.link}">Access Resource</a>
        `;
        resourceList.appendChild(card);
    });
}

window.onload = loadResources;
