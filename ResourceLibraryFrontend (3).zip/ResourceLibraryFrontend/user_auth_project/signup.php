<?php
// Include the database connection file
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['txt'];
    $email = $_POST['email'];
    $phone = $_POST['broj'];
    $password = password_hash($_POST['pswd'], PASSWORD_DEFAULT); // Encrypt the password

    // Check if the email already exists using prepared statements
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email); // 's' means the email is a string
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        echo "Email already exists!";
    } else {
        // Insert user data into the database using prepared statements
        $sql = $conn->prepare("INSERT INTO users (username, email, phone, password) VALUES (?, ?, ?, ?)");
        $sql->bind_param("ssss", $username, $email, $phone, $password); // 'ssss' means all parameters are strings

        if ($sql->execute()) {
            echo "Sign-up successful!";
        } else {
            echo "Error: " . $sql->error;
        }
    }

    $checkEmail->close();
    $sql->close();
}

$conn->close();
?>
