<?php
// Include the database connection file
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['pswd'];

    // Check if the email exists using prepared statements
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);  // 's' means the email is a string
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        // Fetch the user details
        $row = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $row['password'])) {
            echo "Login successful!";
            // Redirect the user to a dashboard or another page
        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "Email not found!";
    }

    $checkEmail->close();
}

$conn->close();
?>
